const $ = id => document.getElementById(id);
const rows = $("processRows");
let lastResult = null, animationTimer = null;
const colors = ["#4568e8","#159b83","#df9141","#8c63d9","#d45b78","#3186b9","#7a9b43","#a36a48"];

function addProcess(id="", at=0, bt=1, priority=1) {
  const tr=document.createElement("tr");
  tr.innerHTML=`<td><input class="process-input pid" aria-label="Process ID" value="${id}" placeholder="P1"></td>
  <td><input class="process-input at" aria-label="Arrival time" type="number" min="0" step="1" value="${at}"></td>
  <td><input class="process-input bt" aria-label="Burst time" type="number" min="1" step="1" value="${bt}"></td>
  <td><input class="process-input pr" aria-label="Priority" type="number" step="1" value="${priority}"></td>
  <td><button class="remove" title="Remove process" aria-label="Remove process">×</button></td>`;
  tr.querySelector(".remove").onclick=()=>{if(rows.children.length>1)tr.remove();};
  rows.appendChild(tr);
}
function loadSample(){rows.innerHTML="";[["P1",0,5,2],["P2",1,3,1],["P3",2,1,3],["P4",3,2,2]].forEach(p=>addProcess(...p));$("error").textContent="";$("results").hidden=true;}
$("sampleBtn").onclick=loadSample;$("addBtn").onclick=()=>addProcess(`P${rows.children.length+1}`,0,1,1);
$("algorithm").onchange=()=>{$("quantumField").style.display=$("algorithm").value==="RR"?"flex":"none";};
$("algorithm").onchange();

function getProcesses(){
  const ps=[...rows.children].map((tr,index)=>({
    id:tr.querySelector(".pid").value.trim(),
    at:Number(tr.querySelector(".at").value),
    bt:Number(tr.querySelector(".bt").value),
    pr:Number(tr.querySelector(".pr").value),
    index,remaining:Number(tr.querySelector(".bt").value)
  }));
  if(!ps.length)throw Error("Add at least one process.");
  if(ps.some(p=>!p.id||!Number.isInteger(p.at)||p.at<0||!Number.isInteger(p.bt)||p.bt<=0||!Number.isFinite(p.pr)||!Number.isInteger(p.pr)))throw Error("Enter unique IDs, non-negative integer arrival times, positive integer burst times and integer priorities.");
  if(new Set(ps.map(p=>p.id)).size!==ps.length)throw Error("Process IDs must be unique.");
  return ps;
}
function simulate(ps,algorithm,quantum,priorityRule){
  let t=0,finished=0,segments=[],completion={};
  const add=(id,start,end)=>{if(end<=start)return;const last=segments.at(-1);if(last&&last.id===id&&last.end===start)last.end=end;else segments.push({id,start,end});};
  const ready=()=>ps.filter(p=>p.at<=t&&p.remaining>0);
  const prioritySort=(a,b)=>priorityRule==="low"?a.pr-b.pr:b.pr-a.pr;
  let guard=0;
  while(finished<ps.length&&guard++<500000){
    const available=ready();
    if(!available.length){const next=Math.min(...ps.filter(p=>p.remaining>0).map(p=>p.at));add("Idle",t,next);t=next;continue;}
    let p;
    const byArrival=(a,b)=>a.at-b.at||a.index-b.index;
    if(algorithm==="FCFS"||algorithm==="RR")p=available.sort(byArrival)[0];
    else if(algorithm==="SJF")p=available.sort((a,b)=>a.bt-b.bt||byArrival(a,b))[0];
    else if(algorithm==="Priority"||algorithm==="PriorityP")p=available.sort((a,b)=>prioritySort(a,b)||byArrival(a,b))[0];
    else p=available.sort((a,b)=>a.remaining-b.remaining||byArrival(a,b))[0];
    let duration;
    if(algorithm==="RR")duration=Math.min(quantum,p.remaining);
    else if(algorithm==="SRTF"||algorithm==="PriorityP")duration=1;
    else duration=p.remaining;
    add(p.id,t,t+duration);t+=duration;p.remaining-=duration;
    if(p.remaining===0){completion[p.id]=t;finished++;}
  }
  if(guard>=500000)throw Error("Simulation exceeded its safety limit.");
  const metrics=ps.map(p=>{const ct=completion[p.id],tat=ct-p.at,wt=tat-p.bt,first=segments.find(s=>s.id===p.id).start;return {...p,ct,tat,wt,rt:first-p.at};});
  return {segments,metrics,avgWT:metrics.reduce((s,p)=>s+p.wt,0)/metrics.length,avgTAT:metrics.reduce((s,p)=>s+p.tat,0)/metrics.length,avgRT:metrics.reduce((s,p)=>s+p.rt,0)/metrics.length,total:t};
}
function render(result){
  $("results").hidden=false;
  $("avgWT").textContent=result.avgWT.toFixed(2);$("avgTAT").textContent=result.avgTAT.toFixed(2);$("avgRT").textContent=result.avgRT.toFixed(2);$("totalTime").textContent=result.total;
  const ids=[...new Set(result.segments.filter(s=>s.id!=="Idle").map(s=>s.id))];
  const color=id=>colors[ids.indexOf(id)%colors.length];
  const gantt=$("gantt");gantt.innerHTML="";
  result.segments.forEach((s,i)=>{const b=document.createElement("div");b.className="gantt-block"+(s.id==="Idle"?" idle":"");b.textContent=s.id;b.style.background=s.id==="Idle"?"#aab3c2":color(s.id);b.style.flex=`${s.end-s.start} 0 0`;b.dataset.index=i;gantt.appendChild(b);});
  const times=[result.segments[0]?.start??0,...result.segments.map(s=>s.end)];$("timeline").innerHTML=times.map(n=>`<span>${n}</span>`).join("");
  $("legend").innerHTML=ids.map(id=>`<span><i style="background:${color(id)}"></i>${id}</span>`).join("")+`<span><i style="background:#aab3c2"></i>Idle</span>`;
  $("resultRows").innerHTML=result.metrics.map(p=>`<tr><td><b>${escapeHtml(p.id)}</b></td><td>${p.at}</td><td>${p.bt}</td><td>${p.ct}</td><td>${p.tat}</td><td>${p.wt}</td><td>${p.rt}</td></tr>`).join("");
  $("results").scrollIntoView({behavior:"smooth",block:"start"});
}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
$("runBtn").onclick=()=>{
  try{
    if(animationTimer)clearInterval(animationTimer);
    const ps=getProcesses(),algo=$("algorithm").value,q=Number($("quantum").value);
    if(algo==="RR"&&(!Number.isInteger(q)||q<=0))throw Error("Time quantum must be a positive integer.");
    lastResult=simulate(ps,algo,q,$("priorityRule").value);render(lastResult);$("error").textContent="";
  }catch(e){$("error").textContent=e.message;$("results").hidden=true;}
};
$("animateBtn").onclick=()=>{
  if(!lastResult)return;
  if(animationTimer)clearInterval(animationTimer);
  const blocks=[...$("gantt").children];blocks.forEach(b=>b.classList.remove("active","dim"));
  let i=0;$("animateBtn").textContent="Ⅱ Pause animation";
  animationTimer=setInterval(()=>{
    blocks.forEach((b,j)=>{b.classList.toggle("active",j===i);b.classList.toggle("dim",j!==i);});
    i++;
    if(i>=blocks.length){clearInterval(animationTimer);animationTimer=null;$("animateBtn").textContent="↻ Replay animation";blocks.forEach(b=>b.classList.remove("active","dim"));}
  },650);
};
loadSample();
